const urlParams = new URLSearchParams(window.location.search);
const site = urlParams.get('site');
const category = urlParams.get('category');
function closeTab() {
    chrome.runtime.sendMessage({'type':'CLOSE_TAB'})
}
/*const label = document.getElementById("takeMeBackLabelLink")
label.onclick = function (){
    closeTab()
}*/
const basediv = document.getElementById("takeMeBackLabel")
basediv.onclick = function (){
    closeTab()
}

const level1Page1Texts  = ["This is off task, isn't it?",
    "Shouldn't you be doing school work right now?",
    "This isn't school work, is it?",
    "You didn't mean to wander off task, right?",
    "Whoops! Is that what you meant to do?",
    "Pretty sure you didn't mean to do that, right?",
    "Are you sure you meant to do that?",
    "Would you like to try that again?",
    "Let's try that again, shall we?"]
const tellMeMore = document.getElementById("tellMeMoreLink")
tellMeMore.onclick = function (){
    document.getElementById("level1Text2").style.display = "block"
    document.getElementById("level1Text1").style.display = "none"
    const oval = document.getElementById("level1Text2")
    let host = site
    host = host.replaceAll("www.","")
    let html = level1_2.replaceAll("HOSTNAME",host)
    oval.innerHTML = html.replaceAll("CATEGORY",category)
    document.getElementById("tellMeMoreLink").style.display = "none"
}
const level1_2 =  'The link you clicked,<br/>\n' +
    ' \'HOSTNAME\' ,<br/>' +
    ' has content related to<br/>' +
    '\'CATEGORY\' <br/>' +
    ' and looks off task. <br/></br>' +
    'If you think this isn\'t right,</br>' +
    'ask your coach.'

function getRandomLevel1Page1Text() {
    const randomNumber = Math.floor(Math.random()*level1Page1Texts.length);
    return level1Page1Texts[randomNumber];
}

let text1 = document.getElementById("level1Text1");
const innerText = getRandomLevel1Page1Text()
text1.innerText = innerText
document.getElementById("level1Text2").style.display = "none"
document.getElementById("level1Text1").style.display = "block"



